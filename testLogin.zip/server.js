require('dotenv').config()

const fastify = require('fastify')({ logger: true })
const bcrypt = require('bcrypt')
const pool = require('./db')
const path = require('path')

fastify.register(require('@fastify/static'), {
  root: path.join(__dirname, 'public'),
})


fastify.post('/register', async (request, reply) => {
  const { username, password } = request.body

  if (!username || !password) {
    return reply.status(400).send({ error: 'Нет данных' })
  }

  // хешируем пароль
  const hash = await bcrypt.hash(password, 10)

  try {

    await pool.query(
      'INSERT INTO "User" (user_name, user_password) VALUES ($1, $2)',
      [username, hash]
    )

    return { message: 'Пользователь создан' }

  } catch (err) {
    console.error(err)

    return reply.status(500).send({ error: 'Ошибка сервера' })
  }
})


// получить все логины
fastify.get('/users', async (request, reply) => {
  try {
    const result = await pool.query(
      'SELECT user_name FROM "User"'
    )

    return result.rows

//     {
//   rows: [ { username: 'user1' }, { username: 'user2' } ],
//   rowCount: 2,
//   command: 'SELECT',
//   fields: [ ... ]
// }

  } catch (err) {
    console.error(err)
    return reply.status(500).send({ error: 'Ошибка сервера' })
  }
})

fastify.listen({ port: 3000 }, err => {
  if (err) {
    console.error(err)
    process.exit(1)
  }
})